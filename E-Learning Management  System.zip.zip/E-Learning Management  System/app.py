from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Database config
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

# ----------------------
# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

# ----------------------
# Home/Login Page
@app.route('/')
def index():
    return render_template('index.html')

# ----------------------
# Signup Page
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password').strip()

        if not username or not password:
            flash('Username and password are required.', 'error')
            return redirect(url_for('signup'))

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please log in.', 'error')
            return redirect(url_for('index'))

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()

        flash('Signup successful! Please log in.', 'success')
        return redirect(url_for('index'))

    return render_template('signup.html')

# ----------------------
# Dashboard (Login)
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password').strip()

        user = User.query.filter_by(username=username).first()

        if not user:
            flash("This account doesn't exist. Please sign up first.", "error")
            return redirect(url_for('index'))

        if user.password != password:
            flash("Incorrect password. Try again.", "error")
            return redirect(url_for('index'))

        session['username'] = user.username
        return render_template('dashboard.html', user=user.username)

    username = session.get('username')
    if not username:
        flash("Please login to access the dashboard.", "error")
        return redirect(url_for('index'))

    return render_template('dashboard.html', user=username)

# ----------------------
# Other Pages
@app.route('/courses')
def courses():
    return render_template('courses.html')

@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if request.method == 'POST':
        answer = request.form.get('q1')
        if answer == '4':
            return render_template('quiz_success.html')
        else:
            return render_template('quiz_fail.html')
    return render_template('quiz.html')

@app.route('/submit')
def submit():
    return render_template('submit.html')

@app.route('/progress')
def progress():
    return render_template('progess.html')  # Still typo

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))

# ----------------------
# Run the App
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create tables if not exist
    app.run(debug=True, host='0.0.0.0', port=5000)
