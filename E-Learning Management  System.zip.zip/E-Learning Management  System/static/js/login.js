// Save login info to localStorage when form is submitted
function saveToLocalStorage() {
  const username = document.querySelector('input[name="username"]').value;
  const password = document.querySelector('input[name="password"]').value;

  localStorage.setItem('username', username);
  localStorage.setItem('password', password);  // Not secure in real apps
}

// Autofill fields when the page loads
window.onload = function () {
  const savedUser = localStorage.getItem('username');
  const savedPass = localStorage.getItem('password');

  if (savedUser) document.querySelector('input[name="username"]').value = savedUser;
  if (savedPass) document.querySelector('input[name="password"]').value = savedPass;
};
